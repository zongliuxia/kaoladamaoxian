/* */
$(function() {
	$(".d-p-information .img-area").slick({
        autoplay: true,
        arrows:false,
        autoplaySpeed: 3000,
        dots:true
    });
});