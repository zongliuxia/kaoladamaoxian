/**
 * HoverAccordion - jQuery plugin for intuitively opening accordions and menus
 *
 * Copyright (c) 2008-2010 Bernd Matzner (http://matznermatzner.de/en/bernd)
 *
 * Dual licensed under the MIT and GPL licenses:
 * http://www.opensource.org/licenses/mit-license.php
 * http://www.gnu.org/licenses/gpl.html
 *
 * Version: 0.9.2
 *
 * Requires jQuery 1.4.4 or higher
 */
(function($) {
    'use strict';

    $.fn.hoverAccordion = function(opts) {
        // Setup options
        var options = jQuery.extend({
            // Speed at which the subitems open up - valid options are: slow,
            // normal, fast, or integer for duration in milliseconds
            speed: 'fast',
            // true: Automatically activate items with links corresponding to
            // the current page, 2: Activate item #2 (numbering starts with 1!)
            activateItem: true,
            // true: Set the height of each accordion item to the size of the
            // largest one, false: Leave height as is
            keepHeight: false,
            // true: Handle accordion on click only rather than hovering, false:
            // React to hovering
            onClickOnly: false,
            // Class name of the initially active element
            classActive: 'active',
            // Class name for header items
            classHeader: 'header',
            // Class name for hover effect
            classHover: 'hover',
            // Class name for open header items
            classOpen: 'opened',
            // Class name for closed header items
            classClosed: 'closed'
        }, opts);

        // Current hover status
        var container = this;

        // Current URL
        var pageHref = window.location.href;

        // Interval for detecting intended element activation
        var i = 0;

        // Change display status of subitems when hovering
        var doHover = function(itemList, itemHeader, listHeight) {

            // Change only one display status at a time
            var oldList = $(container).find('.' + options.classOpen).closest(
                'li').find('ul:first');

            if (false === oldList.is(':animated')) {
                if (options.keepHeight === true) {
                    listHeight = maxHeight;
                }

                // Change display status if not already open
                if (itemHeader.hasClass(options.classOpen) === false) {
                    itemList.children().show();
                    itemList.animate({
                        height: listHeight
                    }, {
                        step: function(n, fx) {
                            itemList.height(listHeight - n);
                        },
                        duration: options.speed
                    });

                    oldList
                        .animate({
                            height: 0
                        }, {
                            step: function(n, fx) {
                                itemList.height(listHeight - n);
                            },
                            duration: options.speed
                        })
                        .children()
                        .hide();

                    // Switch classes for headers
                    itemHeader
                        .addClass(options.classOpen)
                        .removeClass(options.classClosed);

                    oldList
                        .closest('li')
                        .removeClass(options.classActive)
                        .find('a:first')
                        .addClass(options.classClosed)
                        .removeClass(options.classOpen);
                }
            }
        };

        var itemNo = 0;
        var maxHeight = 0;
        var itemList_active_index = 0;
        var that = this;
        $(this).children('li').find('a:first').each(function(index, el) {

            $(el).click(function(event) {
                /* Act on the event */
                if (itemList_active_index !== index) {
                    $(that).find('li').removeClass(options.subactive);
                }
                itemList_active_index = index;
                //console.log(itemList_active_index);
            });
        });
        // Setup initial state and hover events
        $(this).children('li').each(function(index) {
            /* item表示$对象的每一个li*/
            var item = $(this),
                isActive = false,
                itemHeader = item.find('a:first').addClass(options.classHeader),
                itemHref,
                itemList,
                listHeight;

            itemNo++;
            /* li 下的ul*/
            itemList = item.find('ul:first');

            if (itemHeader.length > 0) {
                /* 如果有header*/
                // Hover effect for all links
                itemHeader.hover(function() {
                    /* 加类去类*/
                    itemHeader.addClass(options.classHover);
                }, function() {
                    itemHeader.removeClass(options.classHover);
                });
                /* 标题头的链接*/
                itemHref = itemHeader.attr('href');

                if (itemHref === '#') {
                    // Add a click event if the header does not contain a link
                    itemHeader.click(function() {
                        this.blur();
                        return false;
                        //$(this).parent().parent()
                    });
                } else if (options.activateItem === true &&
                    pageHref.indexOf(itemHref) > 0 &&
                    pageHref.length - pageHref.lastIndexOf(itemHref) === itemHref.length) {
                    isActive = true;
                    item.addClass(options.classActive);
                    itemList.parent().find('li').removeClass(options.subactive);
                    itemHeader.removeClass(options.classClosed).addClass(
                        options.classOpen);
                }
            }
            itemHeader.click(function() {
                //this.blur();
                //return false;
                //$(this).parent().parent().find('li').removeClass(options.subactive);
                if (!itemHeader.find(options.subactive) && !isActive) {
                    $(this).parent().parent().find('li').removeClass(options.subactive);
                }
                if (!isActive) {
                    //
                }

            });
            itemList.on('click', 'li', function(event) {
                event.preventDefault();
                /* Act on the event */
                $(this).parent().parent().find('li').removeClass(options.subactive);
                $(this).addClass(options.subactive);
                //console.log(options.subactive);
                //console.log($(this).html());
            });
            // Initialize subitems
            if (itemList.length > 0) {
                listHeight = itemList.height();

                if (maxHeight < listHeight) {
                    maxHeight = listHeight;
                }

                if (options.onClickOnly === true) {
                    itemHeader.click(function() {
                        doHover(itemList, itemHeader, listHeight);
                    });
                } else {
                    // Bind hover events to all headers of sublists
                    itemHeader.hover(function() {
                        i = setInterval(function() {
                            doHover(itemList, itemHeader, listHeight);
                            clearInterval(i);
                        }, 400);
                    }, function() {
                        clearInterval(i);
                    });
                }

                // Set current link to current URL to 'active'
                if (options.activateItem === true) {
                    itemList.children('li').each(function() {
                        var m = $(this).find('a').attr('href');
                        if (m) {
                            if (pageHref.indexOf(m) > 0 &&
                                pageHref.length - pageHref.lastIndexOf(m) === m.length) {
                                isActive = true;
                                item.addClass(options.classActive);
                                itemList.parent().parent().find('li').removeClass(options.subactive);
                                itemHeader
                                    .removeClass(options.classClosed)
                                    .addClass(options.classOpen);
                            }
                        }
                    });
                } else if (parseInt(options.activateItem, 10) === itemNo) {
                    isActive = true;
                    item.addClass(options.classActive);
                    itemList.parent().parent().find('li').removeClass(options.subactive);
                    itemHeader
                        .removeClass(options.classClosed)
                        .addClass(options.classOpen);
                }
            }

            // Close all subitems except for those with active items
            if (!isActive) {
                itemHeader.removeClass(options.classOpen);
                if (itemList.length > 0) {
                    itemList.children().hide();
                    itemHeader.addClass(options.classClosed);
                }
            }
        });

        return this;
    };
})(jQuery);
